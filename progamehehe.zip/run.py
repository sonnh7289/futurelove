from source import app

import source.main.controller

if __name__ == '__main__':
    app.run(host="0.0.0.0",port="18011")
